# src/text_utils.py

import string

def count_vowels(text: str) -> int:
    """Return number of vowels in text."""
    vowels = "aeiouAEIOU"
    return sum(1 for char in text if char in vowels)


def is_palindrome(text: str) -> bool:
    """
    Return True if text is a palindrome.
    Ignore spaces and case.
    """
    # Remove spaces and lowercase
    cleaned = text.replace(" ", "").lower()
    return cleaned == cleaned[::-1]
