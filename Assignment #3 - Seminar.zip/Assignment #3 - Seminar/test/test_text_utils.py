# tests/test_text_utils.py

import pytest
from src.text_utils import count_vowels, is_palindrome


# =========================
# Basic tests
# =========================

def test_count_vowels_basic():
    assert count_vowels("hello") == 2


def test_count_vowels_empty():
    assert count_vowels("") == 0


def test_is_palindrome_basic():
    assert is_palindrome("racecar") is True


def test_is_palindrome_mixed_case():
    assert is_palindrome("RaceCar") is True


# =========================
# Parametrized tests
# =========================

@pytest.mark.parametrize("text,expected", [
    ("madam", True),
    ("nurses run", True),
    ("python", False),
    ("", True),
])
def test_is_palindrome_parametrized(text, expected):
    assert is_palindrome(text) == expected


@pytest.mark.parametrize("text,expected", [
    ("AEIOU", 5),
    ("xyz", 0),
    ("Hello World!", 3),
    ("12345", 0),
])
def test_count_vowels_parametrized(text, expected):
    assert count_vowels(text) == expected


# =========================
# Fixture usage test
# =========================

def test_fixture_phrases(sample_phrases):
    assert len(sample_phrases) == 5
