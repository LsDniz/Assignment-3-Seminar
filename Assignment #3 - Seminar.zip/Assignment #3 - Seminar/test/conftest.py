# tests/conftest.py

import pytest

@pytest.fixture
def sample_phrases():
    return [
        "racecar",
        "Hello World",
        "nurses run",
        "",
        "Python Testing"
    ]